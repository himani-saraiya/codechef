n=int(input())
for i in range(n):
    h=int(input())
    l=h*2
    print(l)