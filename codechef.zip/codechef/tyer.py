n=int(input())
for i in range(n):
    bike=int(input())
    car=int(input())
    tyer1=bike*2
    tyer2=car*4
    print(tyer1+tyer2)