n=int(input())
for i in range(n):
    x=int(input())
    y=int(input())
    if x<y:
        print(y-x)
    if x>y:
        print(x-y)