n=int(input())
for i in range(n):
    h=int(input())
    mh=int(input())
    if h<mh:
        print("NO")
    if h>=mh:
        print("YES")
