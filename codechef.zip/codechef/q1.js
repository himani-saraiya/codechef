var a=require("readline-sync");
var b=a.questionInt("enter age::");
if(b<0){
    console.log(-1*b)
}
else{
    console.log(-1*b)
}