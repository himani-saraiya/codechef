n=int(input())
for i in range(n):
    t=int(input())
    if t>=1 and t<=4:
        print("YES")
    else:
        print("NO")