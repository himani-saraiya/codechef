n=int(input())
for i in range(n):
    if 150<160:
        print("A")
    if 160>150:
        print("B")
    break
