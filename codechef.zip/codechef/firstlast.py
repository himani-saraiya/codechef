n=int(input())
for i in range(n):
    s = input()
    x=(int(s[0]) + int(s[len(s) - 1]))
    print(x)
