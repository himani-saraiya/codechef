n=int(input())
for i in range(n):
    a=int(input())
    b=int(input())
    if a>b:
        print(a-b)
    else:
        print("no need")
