a=int(input())
for i in range(a):
    b=int(input())
    c=int(input())
    d=b+c
    print(d)